$( document ).ready(function() {
  Shiny.addCustomMessageHandler('fun', function(arg) {
 
  })
});
