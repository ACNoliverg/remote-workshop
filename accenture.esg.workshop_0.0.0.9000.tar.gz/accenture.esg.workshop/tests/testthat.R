library(testthat)
library(accenture.esg.workshop)

test_check("accenture.esg.workshop")
