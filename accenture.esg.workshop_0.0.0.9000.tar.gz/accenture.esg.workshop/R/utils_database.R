#' database 
#'
#' @description Spins up a new database connection
#'
#' @return returns a pool object 
#'
#' @noRd
#' 
